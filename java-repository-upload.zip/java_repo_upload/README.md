# Java Lab Programs

Java lab exercises transcribed from `JAVA-EXT-Updated.pdf` and grouped into separate set folders.

## Contents
- [Set-01](Set-01/README.md)
- [Set-02](Set-02/README.md)
- [Set-03](Set-03/README.md)
- [Set-04](Set-04/README.md)
- [Set-05](Set-05/README.md)
- [Set-06](Set-06/README.md)
- [Set-08](Set-08/README.md)
- [Set-09](Set-09/README.md)
- [Set-10](Set-10/README.md)
- [Set-11](Set-11/README.md)

## Source notes
- Set 7 is not present in the supplied PDF.
- The source does not print a Set 9 heading. The LinkedList and Mouse Events exercises between Set 8 and Set 10 are grouped under Set 9 and noted as such.
- Content is transcribed from the PDF; extraction formatting and line wrapping may differ from the original layout.
