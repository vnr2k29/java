# Set 10

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
SET 10 – TRAFFIC LIGHT
Traffic light simulation using Swing radio buttons.
Updated version: JRadioButton, ButtonGroup, ItemListener and a custom JPanel.
 import javax.swing.*;
 import java.awt.*;
 import java.awt.event.*;
 public class Traffic extends JFrame implements ItemListener {
     int colourNum = 0;
     JRadioButton red, yellow, green;
     ButtonGroup cbg;
     String msg = "";
     Traffic() {
         setTitle("Traffic Light");
         setSize(480, 480);
         setLayout(new FlowLayout());
         cbg = new ButtonGroup();
         red = new JRadioButton("RED");
         yellow = new JRadioButton("YELLOW");
         green = new JRadioButton("GREEN");
         cbg.add(red);
         cbg.add(yellow);
         cbg.add(green);
         add(red);
         add(yellow);
         add(green);
         red.addItemListener(this);
         yellow.addItemListener(this);
         green.addItemListener(this);
         add(new TrafficPanel());
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setVisible(true);
     }
     public void itemStateChanged(ItemEvent ie) {
         if (ie.getStateChange() == ItemEvent.SELECTED) {
             if (ie.getSource() == red) {
                 colourNum = 1;
             }
             else if (ie.getSource() == yellow) {
                 colourNum = 2;
             }
             else {
                 colourNum = 3;
             }
             repaint();
         }
     }
     class TrafficPanel extends JPanel {
         public TrafficPanel() {
             setPreferredSize(new Dimension(400, 320));
         }

SET 10 – TRAFFIC LIGHT (continued)
Java Program

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.BLACK);
            g.fillOval(150, 30, 50, 50);
            g.fillOval(150, 110, 50, 50);
            g.fillOval(150, 190, 50, 50);
            switch (colourNum) {
                case 1:
                    g.setColor(Color.RED);
                    g.fillOval(150, 30, 50, 50);
                    msg = "STOP";
                    g.drawString(msg, 220, 60);
                    break;
                case 2:
                    g.setColor(Color.YELLOW);
                    g.fillOval(150, 110, 50, 50);
                    msg = "READY";
                    g.drawString(msg, 220, 140);
                    break;
                case 3:
                    g.setColor(Color.GREEN);
                    g.fillOval(150, 190, 50, 50);
                    msg = "GO";
                    g.drawString(msg, 220, 220);
                    break;
            }
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Traffic());
    }
}

Initially all three lights are black and no message is displayed.
```
