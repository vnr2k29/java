# Set 01

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
SET 1 – Java Lab External

Question: Use Eclipse or NetBeans platform. Create a test project and test class, run it, explore
auto suggestions, auto fill, code formatter, code refactoring and debugging step by step using a
program containing an if-else condition and a for loop.

Program: Calculates factorial and determines whether the result is even or odd.

Java Program

  Java‎
  class DebugTest {
          public static void main(String[] args) {
              int number=5;
              int factorial=1;


              for(int i=1;i<=number;i++) {
                  factorial*=i;
              }


              if(factorial%2==0) {
                  System.out.println(number+"! is Even: "+factorial);
              }
              else {
                  System.out.println(number+"! is Odd: "+factorial);
              }
          }
  }


Output

  C/C++‎
  5! is Even: 120
```
