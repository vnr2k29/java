# Set 04

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
SET 4 – EXCEPTION HANDLING (Q1)
Java program to create a user interface to perform integer division.
Updated version: Swing JFrame with NumberFormatException and ArithmeticException handling.
 import java.awt.*;
 import java.awt.event.*;
 import javax.swing.*;
 public class Add1 extends JFrame implements ActionListener {
     String msg;
     JTextField num1, num2, res;
     JLabel l1, l2, l3;
     JButton div;
     public Add1() {
         setTitle("Division Operation");
         setSize(350, 300);
         setLayout(new FlowLayout());
         l1 = new JLabel("Number 1");
         l2 = new JLabel("Number 2");
         l3 = new JLabel("Result");
         num1 = new JTextField(10);
         num2 = new JTextField(10);
         res = new JTextField(20);
         res.setEditable(false);
         div = new JButton("DIV");
         add(l1);
         add(num1);
         add(l2);
         add(num2);
         add(l3);
         add(res);
         add(div);
         div.addActionListener(this);
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         setVisible(true);
     }
     public void actionPerformed(ActionEvent ac) {
         try {
             int n1 = Integer.parseInt(num1.getText());
             int n2 = Integer.parseInt(num2.getText());
             if (n2 == 0) {
                 throw new ArithmeticException();
             } else {
                 int n3 = n1 / n2;
                 msg = String.valueOf(n3);
             }
         }
         catch (NumberFormatException e) {
             msg = "NumberFormat Exception";
         }
         catch (ArithmeticException e) {
             msg = "Arithmetic Exception";
         }

SET 4 – EXCEPTION HANDLING (Q1) (continued)
Java Program
        res.setText(msg);
    }
    public static void main(String[] args) {
        new Add1();
    }
}

               public void paint(Graphics g) {

                   g.drawString(msg==null?"":msg,30,70);

               }

           }




Question: Create an exception named InsufficientFundsException. Write a bank
withdrawal program that throws the exception when the withdrawal amount exceeds the
balance.

          Java Program

  Java‎

           class InsufficientFundsException extends Exception {

               InsufficientFundsException(String msg) {

                   super(msg);

               }

           }




           public class Main {

               public static void main(String[] args) {

                   double balance=5000;

                   double withdraw=6000;

                 try {

                     if(withdraw>balance) {

                         throw new
         InsufficientFundsException("Insufficient balance");

                     }




                     balance=balance-withdraw;

                     System.out.println("Remaining Balance: "+balance);

                 }

                 catch(InsufficientFundsException e) {

                     System.out.println(e.getMessage());

                 }

             }

         }


        Output

None‎

         Insufficient balance




SET 5 –
```
