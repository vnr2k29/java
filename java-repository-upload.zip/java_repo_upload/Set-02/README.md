# Set 02

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
Set 2 – Packages and OOP

      1.​ Create user-defined packages with multiple classes. Access packages using
          CLASSPATH.
      2.​ Write a basic OOP program using classes, objects and constructors.




File 1: Addition.java

  Java‎
  package mymath;


  public class Addition {
          public int add(int a,int b) {
              return a+b;
          }
  }

File 2: Subtraction.java

  Java‎
  package mymath;


  public class Subtraction {
          public int sub(int a,int b) {
              return a-b;
          }
  }

Compile both classes

  None‎
  javac -d . Addition.java Subtraction.java

Set CLASSPATH (Windows)

  None‎
  set CLASSPATH=.

File 3: Calculator.java

  Java‎
  import mymath.Addition;

  import mymath.Subtraction;


  public class Calculator {
          public static void main(String[] args) {
               Addition obj1=new Addition();
               Subtraction obj2=new Subtraction();


               System.out.println("Addition Result: "+obj1.add(10,5));
               System.out.println("Subtraction Result: "+obj2.sub(10,5));
          }
  }

Compile and Run

  Java‎
  javac Calculator.java
  java Calculator

Output

  None‎
  Addition Result: 15
  Subtraction Result: 5


Folder structure:


  None‎
  Project
  │
  ├── mymath
  │       ├── Addition.java
  │       └── Subtraction.java
  │
  └── Calculator.java


          2b.Write a basic OOP program using classes, objects and constructors.

          Q2. Basic OOP program using classes, objects and constructors.

        Program: Account.java

Java‎


         class Account {

              // Attributes

              String holderName;

              String accountType;

              double balance;




              // 1. No-Argument Constructor

              // Explicitly written, takes no parameters, sets default
         user values.

              public Account() {

                   this.holderName="Unknown";

                   this.accountType="Savings";

                   this.balance=500.0; // Minimum opening balance

              }




              // 2. Parameterized Constructor

              // Takes arguments to customize the object data upon
         creation.

              public Account(String holderName, String accountType,
         double balance) {

                   this.holderName=holderName;

                   this.accountType=accountType;

        this.balance=balance;

    }




    // Method to display account status

    public void displayAccountInfo() {

        System.out.println("Holder: "+holderName+" | Type:
"+accountType+" | Balance: $"+balance);

    }

}




public class Main {

    public static void main(String[] args) {

        // Using No-Argument Constructor

        Account acc1=new Account();




        // Using Parameterized Constructor

        Account acc2=new Account("Alice Smith", "Current",
25000.50);




        // Displaying details

        System.out.println("--- Account Details ---");

        acc1.displayAccountInfo();

                     acc2.displayAccountInfo();

                }

           }


Output:


 None‎
           --- Account Details ---

           Holder: Unknown | Type: Savings | Balance: $500.0

           Holder: Alice Smith | Type: Current | Balance: $25000.5
```
