# Set 03

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
Set 3 – Abstract Class and Interfaces

   1.​ Write a Java program to create an abstract class named Shape containing two integers
         and an empty method named printArea(). Create three subclasses: Rectangle,
         Triangle and Circle. Each class should implement printArea() to print its area.

         Program

 Java‎


           abstract class Shape {

    abstract void printArea();

}




class Rectangle extends Shape {

    void printArea() {

        System.out.println("Rectangle Area: "+(4*6));

    }

}




class Triangle extends Shape {

    void printArea() {

        System.out.println("Triangle Area: "+(0.5*4*6));

    }

}




class Circle extends Shape {

    void printArea() {

        System.out.println("Circle Area: "+(3.14*5*5));

    }

}

          public class Main {

          public static void main(String[] args) {

                    Rectangle r=new Rectangle();

                    Triangle t=new Triangle();

                    Circle c=new Circle();




                    r.printArea();

                    t.printArea();

                    c.printArea();

               }

          }

          Output

          Rectangle Area: 24

          Triangle Area: 12.0

          Circle Area: 78.5


        3.b Develop a Java application to implement a currency converter (Dollar to INR, EURO
        to INR, Yen) using Interfaces




Java‎
Interface Currency {

               void convert(double amount);

          }

class Dollar implements Currency {

    public void convert(double amount) {

        System.out.println("Dollar to INR: "+(amount*88));

    }

}




class Euro implements Currency {

    public void convert(double amount) {

        System.out.println("Euro to INR: "+(amount*102));

    }

}




class Yen implements Currency {

    public void convert(double amount) {

        System.out.println("Yen to INR: "+(amount*0.59));

    }

}




public class Main {

    public static void main(String[] args) {
```
