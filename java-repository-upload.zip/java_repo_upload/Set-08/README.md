# Set 08

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
SET 8 – JAVA LAB EXTERNAL

Q1. Generics – Generic Class Box

Question: Create a generic class called Box that
can hold any type of object. Implement the
following methods:

     1.​ void set(T obj)
     2.​ T get()
     3.​ boolean isEmpty()

Java Program

Java‎



class Box<T> {

        T obj;




        void set(T obj) {

            this.obj=obj;

        }




        T get() {

            return obj;

        }




        boolean isEmpty() {

            return obj==null;

        }

 }




 public class Main {

         public static void main(String[] args) {

             Box<String> b=new Box<>();




             b.set("Ajaz");




             System.out.println("Value: "+b.get());

             System.out.println("Is Empty:
 "+b.isEmpty());

         }

 }

Output

SET 8 – Q2. AUTOBOXING AND UNBOXING
Java program to implement Autoboxing and Unboxing.
Updated version with int, char, Integer and Double examples.
 public class AutoboxingUnboxingDemo {
     public static void main(String[] args) {
          System.out.println("--- Autoboxing Examples ---");
          // Primitive types
          int primitiveInt = 25;
          char primitiveChar = 'A';
          // Autoboxing
          Integer boxedInt = primitiveInt;
          Character boxedChar = primitiveChar;
          System.out.println("Integer Object: " + boxedInt);
          System.out.println("Character Object: " + boxedChar);
          System.out.println("\n--- Unboxing Examples ---");
          // Wrapper objects
          Integer objectInt = Integer.valueOf(100);
          Double objectDouble = Double.valueOf(45.99);
          // Unboxing
          int unboxedInt = objectInt;
          double unboxedDouble = objectDouble;
          System.out.println("Primitive int: " + unboxedInt);
          System.out.println("Primitive double: " + unboxedDouble);
     }
 }
```
