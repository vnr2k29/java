# Set 06

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
SET 6 – JAVA LAB EXTERNAL
Q1(a). Display Table from Text File Using Labels in Grid
Layout
Question: Suppose a table named Table.txt is stored in a text file. The first line is the
header, and remaining lines correspond to rows. Elements are separated by commas. Write a
Java program to display the table using Labels in Grid Layout.

File 1: Employee.txt

Create a text file named Employee.txt.


  None‎
  ID,Name,Salary,Department

  101,Ajaz,25000,CSE

  102,Ahmed,30000,IT

  103,Rahul,28000,ECE

  104,John,35000,CSE


File 2: LabelsInGridLayout.java

  Java‎

  import java.awt.*;

  import java.io.*;

  import java.util.*;

  import javax.swing.*;

public class LabelsInGridLayout {

    public static void main(String[] args) {

        JFrame f=new JFrame("FILE READING EXAMPLE");




        try {

            Scanner st=new Scanner(new FileReader("Employee.txt"));




            while(st.hasNext()) {

                f.add(new JLabel(st.next()));

                f.setLayout(new GridLayout(4,2));

                f.setSize(400,200);

                f.setVisible(true);

            }

        }

        catch(Exception ex) {

            System.out.println("Error reading file");

        }




        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}

Output

FILE READING EXAMPLE

ID

Name

Salary

Department

101

Ajaz

25000

CSE

102

Ahmed

30000

IT

103

Rahul

28000

ECE

Illustration of labels arranged in a grid.




Q1(b). List All Files in a Directory Including
Subdirectories
Question: Write a Java program to list all files in a directory including the files present in all its
subdirectories.

Java Program: ListFilesInDir.java

 Java‎

 import java.io.*;




 public class ListFilesInDir {

         public static void listFiles(File dir) {

             File files[]=dir.listFiles();




             for(File file:files) {

                 if(file.isFile()) {

                     System.out.println(file.getName());

                 }

                 else {

                     System.out.println("Directory: "+file.getName());

                     listFiles(file);

                 }

             }

         }




         public static void main(String args[]) throws IOException {

             File file=new File("C:/Labs");

             listFiles(file);

         }

 }


Sample Output

 None‎

 Directory: Java

 Main.java

 Test.java

 Directory: Programs

 Hello.java

 Demo.java
```
