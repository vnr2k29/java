# Set 05

Source transcription from `JAVA-EXT-Updated.pdf`. Text and code are preserved as extracted; PDF line wrapping may remain.

```text
SET 5 – Q13. Multithreading – Square and
Cube
Question: Create three threads where one thread generates random integers. For an even
number, calculate its square, and for an odd number calculate its cube.

Java Program

  Java‎

  import java.util.Random;




  class Square extends Thread {

          int n;




          Square(int n) {

              this.n=n;

          }




          public void run() {

              System.out.println("Square: "+(n*n));

          }

  }




  class Cube extends Thread {

          int n;

    Cube(int n) {

        this.n=n;

    }




    public void run() {

        System.out.println("Cube: "+(n*n*n));

    }

}




public class Main {

    public static void main(String[] args) {

        Random r=new Random();




        for(int i=0;i<5;i++) {

           int n=r.nextInt(10)+1;




           System.out.println("Number: "+n);




           if(n%2==0) {

               Square s=new Square(n);

                     s.start();

                 }

                 else {

                     Cube c=new Cube(n);

                     c.start();

                 }

             }

         }

 }


Sample Output

 None‎

 Number: 4

 Square: 16

 Number: 3

 Cube: 27

 Number: 6

 Square: 36

 Number: 5

 Cube: 125

 Number: 2

 Square: 4
```
